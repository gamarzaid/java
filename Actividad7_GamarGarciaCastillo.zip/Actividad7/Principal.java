
/**
 * Write a description of class Principal here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */

public class Principal
{
   public static void main(String[] a){
       Menu op=new Menu();
       op.opciones();
   }
}


