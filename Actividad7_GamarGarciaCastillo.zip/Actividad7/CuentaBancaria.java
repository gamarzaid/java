
/**
 * Write a description of class CuentaBancaria here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
import java.util.Scanner;
public class CuentaBancaria
{
    private String cuenta;
    private String nombre;
    private double capital;
    private double interes;
    private double ganancia;
    private double saldo;
    private double monto;//dinero que va a ingresar o retirar
    private Scanner teclado;//para los metodos ingresar y retirar
    //
    public CuentaBancaria(){
        cuenta="";
        nombre="";
        capital=0.0;
        interes=0.0;
        ganancia=0.0;
        saldo=0.0;
        monto=0.0;
    }
    
    public CuentaBancaria(String cuenta,String nombre,double capital,double interes){
        this.cuenta=cuenta;
        this.nombre=nombre;
        this.capital=capital;
        this.interes=interes;
        //this.ganancia=ganancia;
        //this.saldo=saldo;
    }
    
    public String getCuenta(){
        return cuenta;
    }
    
    public void setCuenta(String cuenta){
        this.cuenta=cuenta;
    }
    
    public String getNombre(){
        return nombre;
    }
    
    public void setNombre(String nombre){
        this.nombre=nombre;
    }
    
    public double getCapital(){
        return capital;
    }
    
    public void setCapital(double capital){
        this.capital=capital;
    }
    
    public double getInteres(){
        return interes;
    }
    
    public void setInteres(double interes){
        this.interes=interes;
    }
    
    public double getGanancia(){
        return ganancia;
    }
    
    public void setGanancia(double ganancia){
        this.ganancia=ganancia;
    }
    
    public double getSaldo(){
        return saldo;
    }
    
    public void setSaldo(double saldo){
        this.saldo=saldo;
    }
    
    public double getMonto(){
        return monto;
    }
    
    public void setMonto(double monto){
        this.monto=monto;
    }
    
    public double calculaGanancia(){
        ganancia=capital*interes;
        return ganancia;
    }
    
    public double calculaSaldo(){
        saldo=capital+ganancia;
        return saldo;
    }
    
    public void ingresaDeposito(){
        teclado=new Scanner(System.in);
        System.out.print("Cantidad a depositar: ");
        monto=teclado.nextDouble();
        saldo=saldo+monto;
        System.out.println("Saldo:"+saldo);
    }
    
    public void retiraDinero(){
        teclado=new Scanner(System.in);
        System.out.print("Cantidad a retirar:" );
        monto=teclado.nextDouble();
        if (saldo<monto){
            System.out.println("No tienes saldo suficiente");
        }
        else{
            saldo=saldo-monto;
            System.out.println("Saldo:"+saldo);
        }
    }
}
