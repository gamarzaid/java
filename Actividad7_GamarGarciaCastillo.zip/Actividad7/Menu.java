
/**
 * Write a description of class Menu here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
import java.util.Scanner;
public class Menu
{
    public int opciones(){
        
        int op=0;
        String menu="";
        Scanner teclado = new Scanner(System.in);
        
        CuentaBancaria cliente=new CuentaBancaria();
        //Pedimos los datos
        System.out.println("DATOS DE LA CUENTA BANCARIA");
        System.out.print("Dame el número de cuenta:");
        cliente.setCuenta(teclado.next());
        System.out.print("Dame el nombre:");
        cliente.setNombre(teclado.next());
        System.out.print("Dame el capital invertido:");
        cliente.setCapital(teclado.nextDouble());
        System.out.print("Dame la tasa de interés anual:");
        cliente.setInteres(teclado.nextDouble());
        //Llamamos los métodos
        System.out.println("La ganancia es:"+cliente.calculaGanancia());
        System.out.println("El saldo final es:"+cliente.calculaSaldo());
        do{
            menu="";
            menu+="****** Menú ******\n";
            menu+="1.- INGRESO \n";
            menu+="2.- RETIRO \n";
            menu+="3.- SALDO \n";
            menu+="4.- SALIR ";
            menu+="Elija una opción";
            System.out.println(menu);
            op = teclado.nextInt();
            switch(op){
            case 1:
                cliente.ingresaDeposito();
                break;
            case 2:
                cliente.retiraDinero();
                break;
            case 3:
                System.out.println("Saldo:"+cliente.getSaldo());                
                break;
            }
        }while(op!=4);
        return op;
    }
}



