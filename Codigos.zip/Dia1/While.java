/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Dia1;

/**
 *
 * @author gamar
 */
public class While {
    public static void main(String[] args) {
        int a = 0;
            while(a < 5){
                System.out.println("La variable a vale:" + a);
                a++;
            }
    }
}
