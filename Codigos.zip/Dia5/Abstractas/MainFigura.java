/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Dia5.Abstactas;

/**
 *
 * @author gamar
 */
public class MainFigura {
    public static void main(String[] args) {
        Circulo cir = new Circulo(1,2,3);
        cir.setRadio(5);
        System.out.println(cir.area());
        
    }
}
