/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Voladores;

/**
 *
 * @author gamar
 */
public class Helicoptero extends VehiculoVolador{
    
    @Override
    public void mover(){
        System.out.println("El HELICOPTERO se está moviendo");
    }
    
    public void encenderHelices(){
        System.out.println("Las hélices del helicoptero están girando!!!!");
    }

}
