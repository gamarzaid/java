/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Voladores;

/**
 *
 * @author gamar
 */
public class VehiculoVolador {
    
    private String nombre, marca, matricula;

    public VehiculoVolador() {
    }

    public VehiculoVolador(String nombre, String marca, String matricula) {
        this.nombre = nombre;
        this.marca = marca;
        this.matricula = matricula;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getMatricula() {
        return matricula;
    }

    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }
    
    public void mover(){
        System.out.println("El Vehiculo Volador se está moviendo!!!!");
    }

}
