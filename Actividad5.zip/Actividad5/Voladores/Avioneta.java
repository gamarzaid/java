/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Voladores;

/**
 *
 * @author gamar
 */
public class Avioneta extends VehiculoVolador{
    
    @Override
    public void mover(){
        System.out.println("La AVIONETA se está moviendo");
    }
    
    public void aterrizarAvioneta(){
        System.out.println("La avioneta está aterrizando");
    }

}
