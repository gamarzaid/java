/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author gamar
 */
public class AlumnoIrregular extends Alumno{
    
    
    
    public AlumnoIrregular(String nombre, String cuenta, String semestre, String materias, float promedio){
        super(nombre, cuenta, semestre, materias, promedio);
        //super();
    }
    
    public void asistir_a_clases(){
        System.out.println("El alumno falta muchísimo a clases");
    }
    
    public void estudiar() {
        System.out.println("El alumno tiene bajo desempeño en los exámenes");
    }

}
