
/**
 * Clase Alumno - Curso didáctica Java
 * 
 * @Gamar 
 * @version1
 */
public class Alumno
{
    // Declaramos atributos
    private String nombre;
    private String cuenta;
    private String semestre;
    private String materias;
    private float promedio;
    

    /**
     * Constructor que inicializa atributos
     */
    public Alumno()
    {
        nombre = "";
        cuenta = "";
        semestre = "";
        materias = "";
        promedio = 0;
    }
    
    /**
     * Constructor que recibe parámetros
     */
    public Alumno(String nombre, String cuenta, String semestre, String materias, float promedio)
    {
        this.nombre = nombre;
        this.cuenta = cuenta;
        this.semestre = semestre;
        this.materias = materias;
        this.promedio = promedio;
    }
    
    
    
    /**
     * Getters y Setters
     */
    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public String getCuenta() {
        return cuenta;
    }

    public void setCuenta(String cuenta) {
        this.cuenta = cuenta;
    }
    
    public String getSemestre() {
        return semestre;
    }

    public void setSemestre(String semestre) {
        this.semestre = semestre;
    }
    
    public String getMaterias() {
        return materias;
    }

    public void setMaterias(String materias) {
        this.materias = materias;
    }
    
    public float getPromedio() {
        return promedio;
    }

    public void setPromedio(float promedio) {
        this.promedio = promedio;
    }
    
    /**
     * Método asistir a clases
     */
    
    protected void asistir_a_clases(){
        //System.out.println("El alumno asiste a clases");
    }
    
    
    /**
     * Método estudiar
     */
    
    protected void estudiar(){
        //System.out.println("El alumno asiste a clases");
    }
    

}
