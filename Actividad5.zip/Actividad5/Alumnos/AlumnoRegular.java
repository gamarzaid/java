/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author gamar
 */
public class AlumnoRegular extends Alumno{

    
    
    public void asistir_a_clases(){
        System.out.println("El alumno asiste cotidianamente a clases");
    }
    
    public void estudiar() {
        System.out.println("El alumno estudia para mejorar su aprendizaje");
    }
    
    


}
